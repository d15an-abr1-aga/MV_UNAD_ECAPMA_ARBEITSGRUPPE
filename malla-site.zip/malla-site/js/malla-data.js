/* =========================================================================
   malla-data.js
   -------------------------------------------------------------------------
   Fuente de datos de la malla académica.
   Edita este archivo para corregir nombres, códigos, créditos o
   prerrequisitos — el resto del sitio (colores, layout, interacción)
   se genera automáticamente a partir de esta información.

   NOTA IMPORTANTE:
   Los nombres, códigos y créditos fueron transcritos de la imagen de la
   malla que compartiste. Revísalos con calma: en una tabla tan densa
   es fácil que algún crédito o código quede mal leído. La estructura de
   "prerequisitos" es una PRIMERA aproximación basada en las flechas de
   continuidad visibles en la imagen (ej. Inglés A1 -> A2 -> B1, Anatomía
   -> cursos clínicos, Rotaciones I -> II). Como la imagen no dibuja una
   flecha explícita curso-a-curso, te recomiendo revisar y completar el
   arreglo PREREQUISITOS más abajo con el plan de estudios oficial.
   ========================================================================= */

// Tipo de curso: T = Teórico, P = Práctico, M = Metodológico
// Colores tomados de tu leyenda (naranja / dorado / verde)
const TIPO_INFO = {
  T: { label: "Teórico",       color: "#D26714" },
  P: { label: "Práctico",      color: "#C9930C" },
  M: { label: "Metodológico",  color: "#035B3B" },
};

// Un color por periodo, derivado de tu paleta institucional
// (#00445B, #01333F, #035B3B, #EAEAEA, #D26714), en degradé desde
// las ciencias básicas (azul) hasta la práctica clínica (naranja).
const PERIODO_COLORES = [
  "#00445B", // I
  "#0B5266", // II
  "#166071",// III
  "#1B6E71",// IV
  "#217A66",// V
  "#2E8460", // VI
  "#4C8A52", // VII
  "#7C8A3E", // VIII
  "#AC7A28", // IX
  "#D26714", // X
];

const MALLA = [
  {
    id: "p1", numero: "I", creditos: 19,
    cursos: [
      { id: "p1c1", tipo: "M", creditos: 2, nombre: "Introducción a la Medicina Veterinaria" },
      { id: "p1c2", tipo: "M", creditos: 3, nombre: "Biología celular y molecular", codigo: "30176" },
      { id: "p1c3", tipo: "M", creditos: 3, nombre: "Química orgánica", codigo: "300047" },
      { id: "p1c4", tipo: "M", creditos: 3, nombre: "Fundamentos del enfoque One Health" },
      { id: "p1c5", tipo: "M", creditos: 3, nombre: "Cátedra Unadista", codigo: "80017" },
      { id: "p1c6", tipo: "T", creditos: 3, nombre: "Competencias Comunicativas", codigo: "40003" },
      { id: "p1c7", tipo: "T", creditos: 3, nombre: "Ética y Ciudadanía (grado)", codigo: "400002" },
    ],
  },
  {
    id: "p2", numero: "II", creditos: 19,
    cursos: [
      { id: "p2c1", tipo: "P", creditos: 4, nombre: "Anatomía Veterinaria comparada" },
      { id: "p2c2", tipo: "P", creditos: 2, nombre: "Biología del desarrollo y fisiología animal" },
      { id: "p2c3", tipo: "M", creditos: 3, nombre: "Bioquímica metabólica", codigo: "352001" },
      { id: "p2c4", tipo: "M", creditos: 3, nombre: "Bioética y legislación Veterinaria" },
      { id: "p2c5", tipo: "T", creditos: 3, nombre: "Pensamiento lógico y matemático", codigo: "200611" },
      { id: "p2c6", tipo: "M", creditos: 3, nombre: "Herramientas digitales para la gestión del conocimiento", codigo: "200610" },
    ],
  },
  {
    id: "p3", numero: "III", creditos: 17,
    cursos: [
      { id: "p3c1", tipo: "P", creditos: 3, nombre: "Inmunología" },
      { id: "p3c2", tipo: "M", creditos: 3, nombre: "Nutrición animal", codigo: "201110" },
      { id: "p3c3", tipo: "M", creditos: 3, nombre: "Genética", codigo: "201105" },
      { id: "p3c4", tipo: "T", creditos: 3, nombre: "Estadística Descriptiva Aplicada a las Ciencias Agrarias", codigo: "300032" },
      { id: "p3c5", tipo: "P", creditos: 2, nombre: "Semiología y Competencias Clínicas Veterinarias" },
      { id: "p3c6", tipo: "M", creditos: 3, nombre: "Mercado Agropecuario", codigo: "300005" },
      { id: "p3c7", tipo: "M", creditos: 3, nombre: "Transformación Digital y Tecnologías Emergentes en Medicina Veterinaria" },
      { id: "p3c8", tipo: "P", creditos: 2, nombre: "Prestación del Servicio Social Unadista", nota: "Requisito de grado", codigo: "700004" },
    ],
  },
  {
    id: "p4", numero: "IV", creditos: 17,
    cursos: [
      { id: "p4c1", tipo: "M", creditos: 3, nombre: "Inglés A1", codigo: "900001" },
      { id: "p4c2", tipo: "P", creditos: 3, nombre: "Microbiología veterinaria" },
      { id: "p4c3", tipo: "M", creditos: 3, nombre: "Virología veterinaria" },
      { id: "p4c4", tipo: "P", creditos: 2, nombre: "Diseño experimental", codigo: "300004" },
      { id: "p4c5", tipo: "P", creditos: 3, nombre: "Patología general y sistémica" },
      { id: "p4c6", tipo: "T", creditos: 2, nombre: "Farmacología veterinaria" },
      { id: "p4c7", tipo: "T", creditos: 3, nombre: "Diseño y evaluación de proyectos", codigo: "331005" },
    ],
  },
  {
    id: "p5", numero: "V", creditos: 17,
    cursos: [
      { id: "p5c1", tipo: "M", creditos: 3, nombre: "Inglés A2", codigo: "900002" },
      { id: "p5c2", tipo: "P", creditos: 3, nombre: "Fundamentos y Generalidades de Investigación", codigo: "150001" },
      { id: "p5c3", tipo: "P", creditos: 2, nombre: "Toxicología veterinaria" },
      { id: "p5c4", tipo: "P", creditos: 2, nombre: "Patología diagnóstica y de laboratorio clínico" },
      { id: "p5c5", tipo: "M", creditos: 3, nombre: "Farmacología veterinaria" },
      { id: "p5c6", tipo: "M", creditos: 3, nombre: "Bienestar animal", codigo: "201570" },
      { id: "p5c7", tipo: "T", creditos: 1, nombre: "Electiva campo de formación complementaria: Derechos de los animales", codigo: "300032" },
    ],
  },
  {
    id: "p6", numero: "VI", creditos: 20,
    cursos: [
      { id: "p6c1", tipo: "M", creditos: 3, nombre: "Inglés B1", codigo: "900003" },
      { id: "p6c2", tipo: "P", creditos: 4, nombre: "Imagenología Veterinaria" },
      { id: "p6c3", tipo: "P", creditos: 4, nombre: "Cirugía" },
      { id: "p6c4", tipo: "P", creditos: 2, nombre: "Medicina interna de rumiantes" },
      { id: "p6c5", tipo: "P", creditos: 2, nombre: "Fundamentos y Fisiología Reproductiva" },
      { id: "p6c6", tipo: "M", creditos: 2, nombre: "Trabajo de Grado", codigo: "204015" },
      { id: "p6c7", tipo: "T", creditos: 1, nombre: "Electivo de formación complementaria" },
    ],
  },
  {
    id: "p7", numero: "VII", creditos: 17,
    cursos: [
      { id: "p7c1", tipo: "P", creditos: 3, nombre: "Medicina y Producción Acuícola" },
      { id: "p7c2", tipo: "P", creditos: 3, nombre: "Prácticas clínicas integradas I" },
      { id: "p7c3", tipo: "P", creditos: 3, nombre: "Medicina interna de pequeños animales" },
      { id: "p7c4", tipo: "P", creditos: 3, nombre: "Epidemiología y salud pública Veterinaria" },
      { id: "p7c5", tipo: "T", creditos: 2, nombre: "Medicina interna en Equinos" },
      { id: "p7c6", tipo: "P", creditos: 3, nombre: "Biotecnologías y Manejo Reproductivo" },
      { id: "p7c7", tipo: "P", creditos: 3, nombre: "Electivo Disciplinar Específico Línea 1" },
    ],
  },
  {
    id: "p8", numero: "VIII", creditos: 16,
    cursos: [
      { id: "p8c1", tipo: "P", creditos: 4, nombre: "Prácticas clínicas integradas II" },
      { id: "p8c2", tipo: "P", creditos: 3, nombre: "Medicina de urgencias y cuidados intensivos" },
      { id: "p8c3", tipo: "P", creditos: 3, nombre: "Medicina de fauna silvestre y exótica" },
      { id: "p8c4", tipo: "P", creditos: 2, nombre: "Medicina y producción aviar" },
      { id: "p8c5", tipo: "P", creditos: 2, nombre: "Medicina Interna de porcinos" },
      { id: "p8c6", tipo: "M", creditos: 2, nombre: "Electivo DC" },
    ],
  },
  {
    id: "p9", numero: "IX", creditos: 17,
    cursos: [
      { id: "p9c1", tipo: "P", creditos: 2, nombre: "Rotaciones clínicas I" },
      { id: "p9c2", tipo: "M", creditos: 1, nombre: "Salud de hato y gestión sanitaria" },
      { id: "p9c3", tipo: "T", creditos: 3, nombre: "Electivo de formación complementaria" },
      { id: "p9c4", tipo: "M", creditos: 3, nombre: "Sociología rural", codigo: "30174" },
      { id: "p9c5", tipo: "M", creditos: 3, nombre: "Electivo Disciplinar Específico Línea 2" },
      { id: "p9c6", tipo: "P", creditos: 3, nombre: "Electivo IBC" },
      { id: "p9c7", tipo: "P", creditos: 2, nombre: "Electivo DC" },
    ],
  },
  {
    id: "p10", numero: "X", creditos: 10,
    cursos: [
      { id: "p10c1", tipo: "P", creditos: 4, nombre: "Rotaciones clínicas II" },
      { id: "p10c2", tipo: "M", creditos: 3, nombre: "Electivo Disciplinar Específico Línea 3" },
      { id: "p10c3", tipo: "M", creditos: 3, nombre: "Electivo IBC" },
    ],
  },
];

/* -------------------------------------------------------------------------
   PREREQUISITOS
   -------------------------------------------------------------------------
   Mapa: { idDelCurso: [idsDeSusPrerrequisitos] }
   Primera aproximación según las secuencias más evidentes de la malla
   (idiomas, cadenas temáticas y rotaciones). Complétalo con el pénsum
   oficial para que el efecto de "elevar" cursos sea 100% preciso.
   ------------------------------------------------------------------------- */
const PREREQUISITOS = {
  // Idiomas
  "p5c1": ["p4c1"],              // Inglés A2 requiere Inglés A1
  "p6c1": ["p5c1"],              // Inglés B1 requiere Inglés A2

  // Ciencias básicas -> bioquímica / fisiología
  "p2c3": ["p1c3"],              // Bioquímica metabólica requiere Química orgánica
  "p2c2": ["p1c2"],              // Biología del desarrollo requiere Biología celular y molecular

  // Anatomía -> cursos clínicos
  "p3c1": ["p2c1"],              // Inmunología requiere Anatomía Veterinaria comparada
  "p4c5": ["p3c1"],              // Patología general y sistémica requiere Inmunología
  "p5c4": ["p4c5"],              // Patología diagnóstica requiere Patología general y sistémica

  // Microbiología / virología / parasitología -> clínica
  "p4c2": ["p3c1"],              // Microbiología veterinaria requiere Inmunología
  "p4c3": ["p4c2"],              // Virología veterinaria requiere Microbiología veterinaria

  // Farmacología -> cirugía / medicina interna
  "p5c5": ["p4c6"],              // Farmacología veterinaria (V) requiere Farmacología veterinaria (IV)
  "p6c3": ["p5c5"],              // Cirugía requiere Farmacología veterinaria

  // Investigación -> trabajo de grado
  "p5c2": ["p4c7"],              // Fundamentos de Investigación requiere Diseño y evaluación de proyectos
  "p6c6": ["p5c2"],              // Trabajo de Grado requiere Fundamentos de Investigación

  // Medicina interna por especies -> integradas -> rotaciones
  "p7c2": ["p6c3", "p6c4"],      // Prácticas clínicas integradas I requiere Cirugía y Medicina interna de rumiantes
  "p8c1": ["p7c2"],              // Prácticas clínicas integradas II requiere Prácticas clínicas integradas I
  "p9c1": ["p8c1"],              // Rotaciones clínicas I requiere Prácticas clínicas integradas II
  "p10c1": ["p9c1"],             // Rotaciones clínicas II requiere Rotaciones clínicas I

  // Servicio social como requisito de grado
  "p6c6b": [],
};

// Exponer globalmente para malla.js
window.MALLA_DATA = { MALLA, PREREQUISITOS, TIPO_INFO, PERIODO_COLORES };
